import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService, TokenService } from '@app/_services';
import { LoaderService } from '@app/_services/loader.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-bank-b2c',
  templateUrl: './bank-b2c.component.html',
  styleUrls: ['./bank-b2c.component.css']
})
export class BankB2cComponent implements OnInit {
  token;
  data;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tokenService: TokenService,
    private accService: AccountService,
    private loaderService: LoaderService,
    private cookie: CookieService

  ) { }

  ngOnInit(): void {
    // this.loaderService.showSpinner(true);
    // this.route.params.subscribe(params => {
    //   if (params.token) {
    //     // this.loaderService.showSpinner(true);
    //     this.token = params.token;
    //     // this.data = params.query;
    //     // localStorage.setItem('user', this.data);
    //     if (this.token.indexOf('Bearer ') > -1) {
    //       this.token = this.token.substring(7, this.token.length);
    //       this.tokenService.token = this.token;
    //     }
    //     // this.tokenService.token = this.token;
    //     this.tokenService.isTokenSubject.next(this.token);
    //     // this.router.navigate(['/quickquote']);
    //   }

    //   else {
    //     this.token = null;
    //   }
    // });


    this.tokenService.token = true;
    console.log(this.tokenService.token, 'inside b2c');

    this.route.queryParams.subscribe(params => {
      this.data = params;


      this.accService.setUser(this.data);

      if (this.data.bankCustomer == 'false' && this.data.insurerUser == 'false') {
        this.router.navigate(['/mycustomers']);
      } else if (this.data.bankCustomer == 'true') {
        this.router.navigate(['/quickquote']);
      }
    });
  }

}
