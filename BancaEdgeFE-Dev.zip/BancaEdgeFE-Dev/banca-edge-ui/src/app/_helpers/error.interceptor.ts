import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AccountService, AlertService, TokenService } from '@app/_services';
import { Router } from '@angular/router';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(
    private accountService: AccountService,
    private alertService: AlertService,
    private tokenService: TokenService,
    private router: Router
  ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(catchError(err => {
      if (err.status === 401) {
        this.accountService.logout();
        this.tokenService.removeToken();
        this.router.navigateByUrl('/account/login');
        return throwError('Invalid user or password');
      }
      // if (err.status == 400) {
      //   const error = (err.error.details.join('\n') + err.error.message) || "Client Error";

      //   console.log("400 HTTP ERROR" + error);
      //   return throwError("Please fix errors " + error);
      // }
      else if (err.status === 500) {
        console.log('insinde erroe interceptor');
        const error = err.error.message || "Server Error"
        return throwError("Sorry the server was unable to process your request " + error);
      }

      if (err) {
        // const error = err.error.message || "General Error";
        // console.log(error);
        return throwError(err);
      }
      else {
        return throwError('Unknown Error');
      }


    }));
  }
}
