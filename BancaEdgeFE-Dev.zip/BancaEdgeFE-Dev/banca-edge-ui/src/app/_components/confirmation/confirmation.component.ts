import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProposalService } from '@app/proposal/services/proposal.service';
import { PolicyVaultService } from '@app/_services/policy-vault.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css'],
})
export class ConfirmationComponent implements OnInit {
  insurerId;

  appNo;

  applicationDetails;

  downloadDocuments;

  data;

  confirmation: Confirmation = {
    status: '',
    policyNo: '',
    premiumPaid: '',
    paymentReferenceNo: '',
    message: '',
    appNo: '',
    coiNo: '',
    logoUrl: '',
    policyEndDate: '',
    policyStartDate: '',
    receiptNo: '',
  };

  constructor(
    private route: ActivatedRoute,
    private policyVaultService: PolicyVaultService,
    private proposalService: ProposalService,
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.insurerId = params.insurerId;
      this.appNo = params.appNo;
    });
    console.log('insurerId: ', this.insurerId, ' appNo: ', this.appNo);
    this.route.queryParams.subscribe((queryParams) => {
      console.log('query params', queryParams);
      this.confirmation.status = queryParams.status;
      this.confirmation.policyNo = queryParams.policyNo;
      this.confirmation.premiumPaid = queryParams.premiumPaid;
      this.confirmation.paymentReferenceNo = queryParams.paymentReferenceNo;
      this.confirmation.appNo = queryParams.appNo;
      this.confirmation.coiNo = queryParams.coiNo;
      this.confirmation.logoUrl = queryParams.logoUrl;
      this.confirmation.message = queryParams.message;
      this.confirmation.receiptNo = queryParams.receiptNo;
      this.confirmation.policyStartDate = queryParams.policyStartDate;
      this.confirmation.policyEndDate = queryParams.policyEndDate;
    });

    this.proposalService.getApplicationbyApplicationNo(this.appNo).subscribe((data) => {
      this.data = data;
    });
  }

  downloadProposalForm(applicationNumber, documentType) {
    this.applicationDetails = {
      applicationNo: applicationNumber,
      // applicationNo: '12750546319',
      documentType: documentType,
    };
    this.policyVaultService.downloadProposalForm(this.applicationDetails).subscribe(
      (download) => {
        if (download['documents'] !== null) {
          this.downloadDocuments = download['documents'];
          // this.downloadPdf(this.downloadDocuments[0]?.documentUrl, this.downloadDocuments[0]?.applicationNo)
          window.open(this.downloadDocuments[0]?.documentUrl, '_blank');
        }
      },
      () => {
        console.log('error downloading');
      },
    );
  }
}

interface Confirmation {
  status: string;
  policyNo: string;
  premiumPaid: string;
  paymentReferenceNo: string;
  appNo: string;
  coiNo: string;
  message: string;
  logoUrl: string;
  receiptNo: string;
  policyStartDate: string;
  policyEndDate: string;
}
