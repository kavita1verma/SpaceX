import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaymentApprovalComponent } from './payment-approval.component';

const routes: Routes = [
    { path: '', component: PaymentApprovalComponent, pathMatch: 'full' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PaymentApprovalRoutingModule { }
