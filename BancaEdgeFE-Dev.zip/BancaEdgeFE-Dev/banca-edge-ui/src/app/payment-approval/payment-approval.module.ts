import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { SharedModule } from '@app/shared/shared.module';
import { PaymentApprovalRoutingModule } from './payment-approval-routing.module';
import { PaymentApprovalComponent } from './payment-approval.component';

@NgModule({
    declarations: [
        PaymentApprovalComponent
    ],
    imports: [
        CommonModule,
        PaymentApprovalRoutingModule,
        MatTableModule,
        MatPaginatorModule,
        SharedModule,
        MatIconModule,
        MatInputModule,
        MatFormFieldModule,
        ReactiveFormsModule
    ]
})
export class PaymentApprovalModule { }
