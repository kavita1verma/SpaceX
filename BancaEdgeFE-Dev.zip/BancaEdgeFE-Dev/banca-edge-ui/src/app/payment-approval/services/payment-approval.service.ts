import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class PaymentApprovalService {

    constructor(private http: HttpClient) { }

    getPaymentsForUSers() {
        return this.http.get('/api/v1/payment/getPaymentsForUser');
    }

    approvePayment(paymentId) {
        return this.http.get(`/api/v1/payment/approvePayment/${paymentId}`);
    }

    issuePolicy(appNo) {
        return this.http.get(`/api/v1/policy/issuePolicy/${appNo}`);
    }

    sendLeadToInsurer(appNo) {
        return this.http.get(`/api/v1/policy/sendLeadtoInsurer/${appNo}`);
    }
}
