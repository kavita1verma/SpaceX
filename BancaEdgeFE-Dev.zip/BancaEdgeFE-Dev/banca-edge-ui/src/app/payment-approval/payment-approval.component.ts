import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { PolicyErrorModalComponent } from '@app/shared/components/policy-error-modal/policy-error-modal.component';
import { SimpleYesNoModalComponent } from '@app/shared/components/simple-yes-no-modal/simple-yes-no-modal.component';
import { AccountService } from '@app/_services/account.service';
import { LoaderService } from '@app/_services/loader.service';
import { PaymentApprovalService } from './services/payment-approval.service';

@Component({
    selector: 'app-payment-approval',
    templateUrl: './payment-approval.component.html',
    styleUrls: ['./payment-approval.component.css']
})
export class PaymentApprovalComponent implements OnInit {

    paymentRequests;
    paymentRequestsCopy;
    paymentRequestsToDisplay;
    pageSize = 5;
    pageIndex = 0;
    currentUser;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    displayedColumns: string[] = [
        'Transaction Date',
        'Application Number',
        'From Account',
        'Insurer',
        'Amount',
        'Status',
        'Actions'
    ];
    searchForm: FormGroup;
    @ViewChild('paginator') paginator: MatPaginator;

    constructor(
        private paymentService: PaymentApprovalService,
        private loaderService: LoaderService,
        private accountService: AccountService,
        private router: Router,
        private dialog: MatDialog,
    ) { }

    ngOnInit() {
        this.searchForm = new FormGroup({
            searchField: new FormControl()
        });
        this.currentUser = this.accountService.userValue;
        this.getPaymentsForUSers();
    }

    getPaymentsForUSers() {
        this.loaderService.showSpinner(true);
        this.paymentService.getPaymentsForUSers().subscribe(data => {
            this.paymentRequestsCopy = data;
            this.paymentRequests = this.paymentRequestsCopy.slice();
            const paymenetsToDisplay = this.pageIndex * this.pageSize;
            this.paymentRequestsToDisplay = this.paymentRequests.slice(paymenetsToDisplay, this.pageSize);
            this.loaderService.showSpinner(false);
        }, error => {
            this.loaderService.showSpinner(false);
        });
    }

    onApproveClicked(paymentId, insurerId, appNo) {
        const dialogRef = this.dialog.open(SimpleYesNoModalComponent, {
            data: 'I confirm that the customer has signed the debit authorization form to allow deduction of premium for this policy',
            panelClass: 'dialog-width'
        });
        dialogRef.afterClosed().subscribe(btn => {
            if (btn === 'yes') {
                this.approvePayment(paymentId, insurerId, appNo)
            }
        });
    }

    approvePayment(paymentId, insurerId, appNo) {
        this.loaderService.showSpinner(true);
        this.paymentService.approvePayment(paymentId).subscribe(data => {
            if ((insurerId === 512) && data['responseCode'] === 0) {
                this.paymentService.sendLeadToInsurer(appNo).subscribe(policyData => {
                    if (policyData['isExternalNavigation']) {
                        const mapForm = document.createElement('form');
                        mapForm.method = policyData['method'];
                        // mapForm.target = '_blank';
                        mapForm.action = policyData['url'];
                        mapForm.style.display = 'none';
                        if (policyData['payload'] && Object.keys(policyData['payload']).length > 0) {
                            Object.keys(policyData['payload']).forEach(key => {
                                const mapInput = document.createElement('input');
                                mapInput.type = 'hidden';
                                mapInput.name = key;
                                mapInput.value = policyData['payload'][key];
                                mapForm.appendChild(mapInput);
                            });
                        }
                        document.body.appendChild(mapForm);

                        mapForm.submit();
                    }
                    this.loaderService.showSpinner(false);
                    this.router.navigate(['/Confirmation', insurerId, policyData['applicationNo']],
                        {
                            queryParams: {
                                status: policyData['status'], paymentReferenceNo: policyData['paymentReferenceNo'],
                                policyNo: policyData['policyNo'], premiumPaid: policyData['premiumPaid'],
                                logoUrl: policyData['logoUrl'], appNo: policyData['applicationNo'],
                                receiptNo: policyData['recieptNo'],
                                paymentGatewayId: policyData['paymentGatewayId'], message: policyData['message']
                            }
                        });
                }, error => {
                    this.loaderService.showSpinner(false);
                })
            } else if (data['responseCode'] === 0) {
                this.paymentService.issuePolicy(appNo).subscribe(policyData => {
                    this.loaderService.showSpinner(false);
                    this.router.navigate(['/Confirmation', insurerId, appNo],
                        {
                            queryParams: {
                                status: policyData['status'], paymentReferenceNo: policyData['paymentReferenceNo'],
                                policyNo: policyData['policyNo'], premiumPaid: policyData['premiumPaid'],
                                logoUrl: policyData['logoUrl'], appNo: policyData['applicationNo'],
                                receiptNo: policyData['recieptNo'],
                                paymentGatewayId: policyData['paymentGatewayId'], message: policyData['message'],
                                coiNo: policyData['coiNo']
                            }
                        });
                }, error => {
                    this.loaderService.showSpinner(false);
                    this.router.navigate(['/Confirmation', insurerId, appNo],
                        {
                            queryParams: {
                                status: 'Error',
                                appNo: appNo,
                                message: 'Error issuing policy. If the amount is debited it\'ll be refunded within 7 working days.'
                            }
                        });
                });
            } else if (data['responseCode'] !== 0) {
                this.loaderService.showSpinner(false);
                this.dialog.open(PolicyErrorModalComponent, {
                    data: data['responseMessage'],
                    panelClass: 'dialog-width'
                });
            }

        }, error => {
            this.loaderService.showSpinner(false);
        });
    }

    onPageChange(event: PageEvent) {
        this.pageSize = event.pageSize;
        this.pageIndex = event.pageIndex;
        const paymenetsToDisplay = event.pageIndex * event.pageSize;
        this.paymentRequestsToDisplay = this.paymentRequests.slice(paymenetsToDisplay, paymenetsToDisplay + event.pageSize);
    }

    onSearchFieldChange() {
        const searchValue = this.searchForm.get('searchField').value.toLocaleLowerCase();
        this.paymentRequests = this.paymentRequestsCopy.slice().filter(paymentRequest => {
            const paymentRequestString = JSON.stringify(paymentRequest);
            if (paymentRequestString.match(searchValue) || paymentRequestString.toLocaleLowerCase().match(searchValue)) {
                return paymentRequest;
            }
        });
        this.paymentRequestsToDisplay = this.paymentRequests.slice(0, this.pageSize);
        this.paginator.pageIndex = 0;
    }
}
