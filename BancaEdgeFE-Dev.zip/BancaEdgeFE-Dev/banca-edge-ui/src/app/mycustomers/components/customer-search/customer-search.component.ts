import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomersService } from '@app/mycustomers/services/customers.service';
import { PolicyErrorModalComponent } from '@app/shared/components/policy-error-modal/policy-error-modal.component';
import { AccountService } from '@app/_services';
import { LoaderService } from '@app/_services/loader.service';
import { QuoteDataService } from '@app/_services/quoteData.service';
import { User } from '@app/_models';
@Component({
  selector: 'app-customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.css'],
})
export class CustomerSearchComponent implements OnInit {
  @Input() isMyCustomerScreen;
  user: User;
  channels = [
    { value: 'KB', viewValue: 'Karnataka Bank' },
    { value: 'IB', viewValue: 'Indian Bank' },
    { value: 'IOB', viewValue: 'Indian Overseas Bank' },
  ];
  searchByForm: FormGroup;
  disableToggle = true;
  isProceed;
  currentCustomer;
  isBankCustomer;
  organizationCode;
  @Output() customerDetails = new EventEmitter<any>();

  constructor(
    private customersService: CustomersService,
    private router: Router,
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private quoteDataRootService: QuoteDataService,
    private loaderService: LoaderService,
    private accountService: AccountService,
  ) {
    this.accountService.user.subscribe((x) => (this.user = x));
  }

  ngOnInit() {
    this.searchByForm = new FormGroup({
      // channel: new FormControl('', Validators.required),
      searchCustomerByMobile: new FormControl(false, Validators.required),
      inputNumber: new FormControl('', Validators.required),
      // dob: new FormControl('', Validators.required)
    });

    this.isBankCustomer = this.user['bankCustomer'];
    this.organizationCode = this.user['organizationCode'];
  }

  onValChange(event) {
    this.searchByForm.get('inputNumber').reset();
  }

  goToIndividual() {
    this.router.navigate(['/mycustomers/addindividualcustomer']);
  }

  goToBusiness() {
    this.router.navigate(['/mycustomers/addbusinesscustomer']);
  }
  enableBtn(event) {
    if (this.searchByForm.get('channel').valid) {
      this.searchByForm.get('searchCustomerByMobile').enable();
    } else {
      this.searchByForm.get('searchCustomerByMobile').disable();
    }
  }
  channelSelected() {
    if (this.searchByForm.get('channel').valid) {
      return true;
    } else {
      return false;
    }
  }
  enableSubmit() {
    if (this.searchByForm.valid) {
      return false;
    } else {
      return true;
    }
  }
  getCustomer() {
    // this.toggle();
    this.currentCustomer = [];
    this.loaderService.showSpinner(true);
    if (this.searchByForm.get('searchCustomerByMobile').value === true) {
      this.customersService
        .getCustomerByMobile(this.searchByForm.get('inputNumber').value)
        .subscribe(
          (customer) => {
            if (customer['responseCode'] === 0) {
              this.currentCustomer = customer;
              this.customerDetails.emit({
                customerDetails: this.currentCustomer,
                isLoadedFromCif: false,
              });

              // this.isProceed = true;
              this.loaderService.showSpinner(false);
              // this.isShowCustomer = true;
            } else {
              this.loaderService.showSpinner(false);

              const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
                data:
                  this.organizationCode === 'CSB'
                    ? 'Invalid Mobile/Client ID number'
                    : customer['responseMessage'],
                panelClass: 'dialog-width',
              });
            }
          },
          (error) => {
            this.loaderService.showSpinner(false);
            this.customerDetails.emit();

            // const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
            //   data: this.organizationCode === 'CSB' ? 'Invalid Mobile/Client ID number' : 'Invalid Mobile/CIF number',
            //   panelClass: 'dialog-width',
            // });

            // this.isShowCustomer = false;
            // this.isProceed = false;
          },
        );
    } else {
      const cifNo = this.searchByForm.get('inputNumber').value;
      this.customersService.getCustomerByCif(this.searchByForm.get('inputNumber').value).subscribe(
        (customer) => {
          console.log('customer =', customer);
          if (customer['responseCode'] === 0) {
            this.currentCustomer = customer;
            this.customerDetails.emit({
              customerDetails: this.currentCustomer,
              isLoadedFromCif: true,
              cifNo,
            });
            // this.isProceed = true;
            this.loaderService.showSpinner(false);
            // this.isShowCustomer = true;
          } else {
            this.loaderService.showSpinner(false);
            const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
              data:
                this.organizationCode === 'CSB'
                  ? 'Cannot find Customer for entered Client ID number'
                  : customer['responseMessage'],
              panelClass: 'dialog-width',
            });

            // this.isShowCustomer = false;
            // this.isProceed = false;
          }
        },
        (error) => {
          console.log(error, '--errorr');
          this.loaderService.showSpinner(false);
          // this.customerDetails.emit(this.currentCustomer);
          // const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
          //   data: this.organizationCode === 'CSB' ? 'Cannot find Customer for entered Client ID number' : 'Cannot find Customer for entered CIF number',
          //   panelClass: 'dialog-width',

          // });

          // this.isShowCustomer = false;
          // this.isProceed = false;
        },
      );
    }
    this.searchByForm.get('inputNumber').reset();
  }
}
