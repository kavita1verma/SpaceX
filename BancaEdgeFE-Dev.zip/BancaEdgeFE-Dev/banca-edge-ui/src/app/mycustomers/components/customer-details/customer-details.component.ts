import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomersService } from '@app/mycustomers/services/customers.service';
import { PolicyPromptModalComponent } from '@app/shared/components/policy-prompt-modal/policy-prompt-modal.component';
import { AccountService } from '@app/_services/account.service';
import { LoaderService } from '@app/_services/loader.service';
import { QuoteDataService } from '@app/_services/quoteData.service';
import { MatDialog } from '@angular/material/dialog';
import { CustomerMobileNoDobModalComponent } from '@app/mycustomers/components/customer-mobile-no-dob-modal/customer-mobile-no-dob-modal.component';
import { User } from '@app/_models';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css'],
})
export class CustomerDetailsComponent implements OnInit, OnChanges {
  user: User;

  isQuoteId;

  productId;

  createApplicationData;

  isBranchUser;

  applicationNo;

  dob;

  mobileNO;

  orgCode;

  @Input() currentCustomer;

  @Input() isMyCustomerScreen;

  @Input() isLoadedFromCif;

  @Input() cifNo;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private quoteDataRootService: QuoteDataService,
    private loaderService: LoaderService,
    private customersService: CustomersService,
    public dialog: MatDialog,
    private accountService: AccountService,
  ) {
    this.accountService.user.subscribe((x) => (this.user = x));
  }

  ngOnChanges() {
    if (this.currentCustomer?.isIndividual) {
      this.checkforDobMobile(this.currentCustomer);
    }
  }

  ngOnInit(): void {
    this.orgCode = this.user.organizationCode;
    this.isBranchUser = this.accountService.isBranchUser;
    this.route.params.subscribe((params) => {
      if (params.productId) {
        this.isQuoteId = true;
        this.productId = params.productId;
        this.createApplicationData = this.quoteDataRootService.getData();
      }
      if (params.primaryMobileNo) {
        this.customersService.getCustomerByMobile(params.primaryMobileNo).subscribe((customer) => {
          this.currentCustomer = customer;
        });
      }
    });
  }

  routeToPolicy(customerId) {
    this.router.navigate(['/policyvault'], { queryParams: { customerId } });
  }

  routeToNeedAnalysis(customerId) {
    this.router.navigate(['/needanalysis/home', customerId]);
  }

  proceedToQuote() {
    // this.isLoading = true;
    this.createApplicationData.customerId = this.currentCustomer?.customerId;
    this.loaderService.showSpinner(true);
    this.quoteDataRootService
      .createHealthApplication(this.productId, this.createApplicationData)
      .subscribe(
        (result) => {
          // this.isLoading = false;
          this.loaderService.showSpinner(false);
          const applicationArr = result;
          this.applicationNo = applicationArr['applicationNo'];
          if (applicationArr['online'] === false) {
            if (this.createApplicationData.lob === 'Life') {
              this.router.navigate(['/proposal', this.productId, this.applicationNo]);
            } else if (this.createApplicationData.lob === 'Health') {
              this.router.navigate(['/quote/offline-purchase', this.applicationNo]);
            } else if (this.createApplicationData.lob === 'Motor') {
              this.router.navigate(['/quote/offline-motor-purchase', this.applicationNo]);
            }
          } else if (applicationArr['online'] === true) {
            if (this.isBranchUser) {
              const dialogRef = this.dialog.open(PolicyPromptModalComponent, {
                data: '',
                panelClass: 'dialog-width',
                disableClose: true,
              });
              dialogRef.afterClosed().subscribe((formType) => {
                this.router.navigate(['/proposal', this.productId, this.applicationNo, formType]);
              });
            } else {
              this.router.navigate(['/proposal', this.productId, this.applicationNo, 'Long']);
            }
          }
        },
        () => {
          // this.isLoading = false;
          this.loaderService.showSpinner(false);
        },
      );
  }

  enableProceed() {}

  checkforDobMobile(customerDetail) {
    let dobTrue = '';
    let mobileNo = '';
    if (customerDetail.hasOwnProperty('dob')) {
      dobTrue = customerDetail.dob;
    }
    if (customerDetail.hasOwnProperty('mobileNo')) {
      mobileNo = customerDetail.mobileNo;
    }
    if (dobTrue === '' || mobileNo === '') {
      const dialogRef = this.dialog.open(CustomerMobileNoDobModalComponent, {
        data: {
          customerdetail: JSON.parse(JSON.stringify(customerDetail)),
          mobilenumber: mobileNo,
          dob: dobTrue,
        },
        panelClass: 'dialog-width',
      });
      dialogRef.afterClosed().subscribe((updateddetails) => {
        this.loaderService.showSpinner(true);
        const user = this.accountService.userValue;
        // this.organizationCode = user.organizationCode;
        const customerData: any = {
          branchCode: user.branchCode,
          dob: updateddetails.dob,
          firstName: updateddetails.firstName,
          gender: updateddetails.gender,
          isIndividual: updateddetails.isIndividual,
          lastName: updateddetails.lastName,
          mobileNo: updateddetails.mobileNo,
          organizationCode: updateddetails.organizationCode,
        };
        const customerid = this.currentCustomer?.customerId;
        // this.currentCustomer = updateddetails;
        this.customersService.updateCustomer(customerData, customerid).subscribe(
          (res) => {
            if (res.hasOwnProperty('responseCode')) {
              if (updateddetails.bankCustomerId !== '') {
                this.customersService.getCustomerByCif(updateddetails.bankCustomerId).subscribe(
                  (res1) => {
                    this.loaderService.showSpinner(false);
                    this.currentCustomer = res1;
                  },
                  () => {
                    this.loaderService.showSpinner(false);
                  },
                );
              } else {
                this.customersService.getCustomerByMobile(updateddetails.mobileNo).subscribe(
                  (res1) => {
                    this.currentCustomer = res1;
                  },
                  () => {
                    this.loaderService.showSpinner(false);
                    // console.log('error = ', error);
                  },
                );
              }
            } else {
              this.loaderService.showSpinner(false);
            }
          },
          () => {
            this.loaderService.showSpinner(false);
            // console.log('error = ', error);
          },
        );
      });
    }
  }
}
