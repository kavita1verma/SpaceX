import { Component } from '@angular/core';

@Component({
  templateUrl: 'layout.component.html',
  styleUrls: ['layout.component.css']})
export class LayoutComponent { }
