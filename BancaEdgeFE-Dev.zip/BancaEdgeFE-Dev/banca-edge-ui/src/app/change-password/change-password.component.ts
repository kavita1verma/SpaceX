import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AccountService, AlertService } from '@app/_services';
import { MustMatch } from '@app/_helpers/must-match.validator';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  form: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private accountService: AccountService,
    private alertService: AlertService
  ) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', [Validators.required,
      Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$')]],
      matchingPassword: ['', Validators.required]
    }, {
      validator: MustMatch('newPassword', 'matchingPassword')
    });
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/mycustomers';
  }

  get f() { return this.form.controls; }

  onSubmit() {
    this.submitted = true;
    this.alertService.clear();
    if (this.form.invalid) {
      return;
    }

    const formObj = this.form.getRawValue();
    const serializedForm = JSON.stringify(formObj);
    const mutatedForm = JSON.parse(serializedForm);
    this.loading = true;
    this.accountService.changePassword(mutatedForm).subscribe(
      data => {
        console.log('data', data);
        this.alertService.info(data['details'][0]);
        setTimeout(() => {
          this.accountService.logout().subscribe(logout => {
            console.log('Logged Out');
            // this.alertService.info('Please login again');
          });
        }, 2000);
      },
      error => {
        // console.log('error', error.error.details[0]);
        this.alertService.error(error.error.details[0]);
        this.loading = false;
      });
  }


  cancel() {
    this.router.navigate([this.returnUrl]);
  }
}
