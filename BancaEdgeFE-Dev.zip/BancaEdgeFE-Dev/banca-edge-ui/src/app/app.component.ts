import { HostListener, Component, OnInit, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';

import { AccountService, TokenService } from './_services';
// import { BlockerService } from './_services';
import { User } from './_models';
import { TranslateService } from '@ngx-translate/core';
import { LoaderService } from './_services/loader.service';
import { NgxSpinnerService } from 'ngx-spinner';

interface Document {
  documentMode?: any;
}
@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'BancaEdge';
  hasToken = false;
  isLoading = false;
  user: User;
  organizationCode;
  constructor(
    private accountService: AccountService,
    private tokenService: TokenService,
    private translateService: TranslateService,
    public loaderService: LoaderService,
    public changeDetect: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private router: Router,
  ) {
    this.accountService.user.subscribe((x) => (this.user = x));
    console.log('user in app component', this.user);
    translateService.setDefaultLang('en');
  }

  ngOnInit() {
    this.organizationCode = this.user?.organizationCode;
    // console.log(this.organizationCode);
    this.loaderService.loadingSpinner.subscribe((val) => {
      if (val) {
        this.spinner.show();
      } else {
        this.spinner.hide();
      }
      // this.changeDetect.detectChanges();
    });
    this.tokenService.isTokenSubject.subscribe((token) => {
      if (!token) {
        this.hasToken = false;
      } else {
        this.hasToken = true;
      }
    });
  }

  isBrowserIE() {
    // console.log('inisde IE')
    return window.document['documentMode'];
  }

  get isUser() {
    return this.accountService.isUser;
  }

  logout() {
    this.accountService.logout();
  }

  @HostListener('window:beforeunload', ['$event'])
  beforeUnloadHandler(event) {
    // localStorage.removeItem('user');
  }
}
