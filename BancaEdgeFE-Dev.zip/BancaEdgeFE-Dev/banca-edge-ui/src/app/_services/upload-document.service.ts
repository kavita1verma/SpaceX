import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';

@Injectable({ providedIn: 'root' })
export class UploadDocumentService {
  constructor(private http: HttpClient) {}

  uploadFile(data) {
    console.log('got the payload', data);

    return this.http.post(`${environment.apiUrl}/api/v1/common/uploaddoc`, data);
  }
}
