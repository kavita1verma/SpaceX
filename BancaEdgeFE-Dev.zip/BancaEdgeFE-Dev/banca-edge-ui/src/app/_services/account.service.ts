import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';

import { environment } from '@environments/environment';
import { User } from '@app/_models';
import { TokenService } from './token.service';
import { CookieService } from 'ngx-cookie-service';

@Injectable({ providedIn: 'root' })
export class AccountService {

  private userSubject: BehaviorSubject<User>;
  public user: Observable<User>;
  private token: string;
  public isBranchUser;
  public orgCode;
  username;
  password;
  isInsurer;

  constructor(
    private router: Router,
    private http: HttpClient,
    private tokenService: TokenService,
    private cookie: CookieService
  ) {
    this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));
    console.log('user', this.userSubject.value);
    if (this.userSubject.value) {

      if (this.userSubject.value['bankCustomer'] === false) {
        this.isBranchUser = this.userSubject.value['bankCustomer'] === false && this.userSubject.value['insurerUser'] === false;
      } else {
        this.isBranchUser = this.userSubject.value['bankCustomer'] == 'false' && this.userSubject.value['insurerUser'] == 'false';
      }
      console.log('inisnde construcoir', this.isBranchUser);

    }
    this.user = this.userSubject.asObservable();
    console.log('bank user', this.isBranchUser);
  }

  public get userValue(): User {
    return this.userSubject.value;
  }

  changePassword(data) {
    const user = localStorage.getItem('currentUser');
    JSON.stringify(user);
    return this.http.post(`${environment.apiUrl}/api/user/changePassword`, data);
  }


  getNotificationList() {
    const user = localStorage.getItem('currentUser');
    JSON.stringify(user);
    const token = window.btoa(user + ':' + user);
    return this.http.get(`${environment.apiUrl}/api/v1/notification/getActiveUserNotifications`);

  }

  resetPassword(username) {
    return this.http.get(`${environment.apiUrl}/api/user/forgotPassword/${username}`)
      .pipe(map(response => {
        return response;
      }));
  }

  markNotificationRead(data) {
    return this.http.post(`${environment.apiUrl}/api/v1/notification/markNotificationRead`, data);
  }

  registerCustomer(customerInfo) {
    return this.http.post(`${environment.apiUrl}/api/user/registerDirectCustomer`, customerInfo);
  }

  login(username, password) {
    this.username = username;
    this.password = password;
    this.token = btoa(username + ':' + password);
    const headers = new HttpHeaders()
      .set('Accept', 'application/json')
      .set('Authorization', 'Basic ' + this.token);

    return this.http.get<User>(`${environment.apiUrl}/api/user/login?data=${new Date().getTime()}`, { headers, observe: 'response' }).pipe(
      map(apiuser => {
        const authHeader = apiuser.headers.get('Authorization');
        if (authHeader.indexOf('Bearer ') > -1) {
          this.token = authHeader.substring(7, authHeader.length);
        } else {
          throwError('Invalid user or password');
        }

        this.tokenService.token = true;
        // this.tokenService.token = this.cookie.get('token');
        this.setUser(apiuser.body);
        // localStorage.setItem('user', JSON.stringify(apiuser.body));
        // this.userSubject.next(JSON.parse(JSON.stringify(apiuser.body)));

        return apiuser.body;
      })
    );

  }

  setUser(user) {

    if (user['bankCustomer'] === false) {
      this.isBranchUser = user['bankCustomer'] === false && user['insurerUser'] === false;
    } else {
      this.isBranchUser = user['bankCustomer'] == 'false' && user['insurerUser'] == 'false';
    }
    this.isInsurer = user['insurerUser'];

    localStorage.setItem('user', JSON.stringify(user));
    console.log('coming in setUser', localStorage.getItem('user'));
    this.userSubject.next(JSON.parse(JSON.stringify(user)));
    // this.isBranchUser = this.userSubject.value['bankCustomer'] == 'false' && this.userSubject.value['insurerUser'] == 'false';
    console.log('coming in setUser', this.isBranchUser);

  }

  validateToken(token) {
    return this.http.get(`${environment.apiUrl}/api/user/validateBankToken`);
  }



  logout() {
    // this.cookie.deleteAll();
    localStorage.setItem('user', null);
    return this.http.get(`${environment.apiUrl}/api/user/logout?data=${new Date().getTime()}`)
      .pipe(
        map(apiresponse => {
        }),
        finalize(() => { this.cleanup(); })
      );
  }

  cleanup() {
    console.log('inisde clean up');
    // localStorage.removeItem('user');
    localStorage.clear();
    this.tokenService.removeToken();
    // this.cookie.delete('token');
    this.userSubject.next(null);
    this.router.navigate(['/account/login']);
  }

  public get isUser(): boolean {
    const roles: string[] = this.userSubject.value.roles;
    if (this.userSubject.value) {
      return true;
    } else {
      return false;
    }
  }


  postEmailAssist(data) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json');
    return this.http.post(`${environment.apiUrl}/api/v1/master/createTicket`, data, { headers });
  }

}
