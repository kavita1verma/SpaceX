import { Component, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { UserDataService } from '../user-data.service';
import { filter } from 'rxjs/operators';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit, OnChanges {
  state = 'gender';

  needAnalysisForm: FormGroup;

  sideNavDisplay = ['/home', '/summary'];

  ageGroup;

  gifImage;

  showSideNav = true;

  customerId;

  isCustomer;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private userData: UserDataService,
  ) { }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      if (params.customerId) {
        this.customerId = params.customerId;
        this.isCustomer = true;
        this.userData.getCustomerById(this.customerId).subscribe((customer) => {
          this.needAnalysisForm.get('genderValue').setValue(customer['gender']);
          this.userData.setUserInfo('gender', customer['gender']);

          if (customer['gender'] === 'M') {
            this.userData.setDisplayInfo('gender', 'Male');
          } else {
            this.userData.setDisplayInfo('gender', 'FeMale');
          }
          this.ageCheck(customer);
          // const timeDiff = Math.abs(Date.now() - new Date(customer['dob']).getTime());
          // const age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
          // this.needAnalysisForm.get('ageValue').setValue(age);
          // this.userData.setDisplayInfo('age', age);
          this.state = 'maritalStatus';

          console.log('customer details', customer, this.needAnalysisForm.get('genderValue').value);
        });
        // this.userData.setCustomerId(this.customerId);
      } else {
        this.customerId = 0;
      }
    });

    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        if (this.sideNavDisplay.findIndex((url) => event.url === url) > -1) {
          this.showSideNav = true;
        } else {
          this.showSideNav = false;
        }
      });

    this.needAnalysisForm = new FormGroup({
      ageValue: new FormControl('', [
        Validators.required,
        Validators.min(18),
        Validators.max(100),
        Validators.minLength(2),
        Validators.maxLength(3),
      ]),
      genderValue: new FormControl('', [Validators.required]),
      maritalStatusValue: new FormControl('', [Validators.required]),
      // occupationValue: new FormControl('', [Validators.required]),
      // socialLifeValue: new FormControl('', [Validators.required]),
      riskTypeValue: new FormControl('', [Validators.required]),
      // houseTypeValue: new FormControl('', [Validators.required]),
      // valuablesValue: new FormControl('', [Validators.required]),
      annualIncomValue: new FormControl('', [
        Validators.required,
        Validators.pattern('^[1-9][0-9]*$'),
        Validators.max(100000000),
        Validators.min(100000),
      ]),
      // savingsValue: new FormControl('', [Validators.required, Validators.min(10000), Validators.max(10000000)]),
      // needLoanValue: new FormControl('', [Validators.required]),
      // kidsNumValue: new FormControl('', [Validators.required]),
      // firstKidAge: new FormControl('', [Validators.required]),
      // secondKidAge: new FormControl('', [Validators.required]),
      // thirdKidAge: new FormControl('', [Validators.required])
    });
    this.userData.onStateChange.subscribe((state) => {
      if (this.needAnalysisForm && !this.needAnalysisForm.valid && state !== null) {
        this.needAnalysisForm.get('genderValue').setValue(this.userData.getUserInfo().gender);
        this.needAnalysisForm.get('ageValue').setValue(this.userData.getUserInfo().age);
        this.needAnalysisForm
          .get('maritalStatusValue')
          .setValue(this.userData.getUserInfo().maritalStatus);
        // this.needAnalysisForm.get('socialLifeValue').setValue(this.userData.getUserInfo().socialLife);
        this.needAnalysisForm.get('riskTypeValue').setValue(this.userData.getUserInfo().riskType);
        // this.needAnalysisForm.get('houseTypeValue').setValue(this.userData.getUserInfo().houseType);
        // this.needAnalysisForm.get('valuablesValue').setValue(this.userData.getUserInfo().valuables);
        this.needAnalysisForm
          .get('annualIncomValue')
          .setValue(this.userData.getUserInfo().annualIncome);
        // this.needAnalysisForm.get('savingsValue').setValue(this.userData.getUserInfo().savings);
        // this.needAnalysisForm.get('needLoanValue').setValue(this.userData.getUserInfo().needLoan);
        // this.needAnalysisForm.get('occupationValue').setValue(this.userData.getUserInfo().occupation);
      }
      if (state) {
        this.state = state;
      }
    });
  }

  ngOnChanges() {
    this.ageGroup = this.userData.getUserInfo().ageGroup;
    this.startAnimation();
  }

  ageCheck(customer) {
    const timeDiff = Math.abs(Date.now() - new Date(customer['dob']).getTime());
    const age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
    this.needAnalysisForm.get('ageValue').setValue(age);
    this.userData.setUserInfo('age', age);
    this.userData.setDisplayInfo('age', age);
    if (age <= 30) {
      this.userData.setUserInfo('ageGroup', 'young');
    } else if (age > 30 && age < 60) {
      this.userData.setUserInfo('ageGroup', 'elder');
    } else {
      this.userData.setUserInfo('ageGroup', 'senior');
    }
  }

  startAnimation() {
    this.ageGroup = this.userData.getUserInfo().ageGroup;
    if (this.userData.getUserInfo().gender === 'M') {
      if (this.ageGroup === 'young') {
        this.gifImage = 'Boy-1';
      } else if (this.ageGroup === 'elder') {
        this.gifImage = 'Boy-2';
      } else if (this.ageGroup === 'senior') {
        this.gifImage = 'Boy-3';
      }
    } else if (this.needAnalysisForm.get('genderValue').value === 'F') {
      if (this.ageGroup === 'young') {
        this.gifImage = 'Lady-1';
      } else if (this.ageGroup === 'elder') {
        this.gifImage = 'Lady-2';
      } else if (this.ageGroup === 'senior') {
        this.gifImage = 'Lady-3';
      }
    }
  }

  exitNeedAnalysis() {
    this.needAnalysisForm.reset();
    this.router.navigateByUrl('/mycustomers');
  }

  stateTransition() {
    console.log('form', this.needAnalysisForm.value);
    if (this.state === 'gender') {
      if (this.needAnalysisForm.get('genderValue').valid) {
        this.state = 'age';
        this.startAnimation();
      } else {
        this.needAnalysisForm.get('genderValue').markAsDirty();
      }
    } else if (this.state === 'age') {
      if (this.needAnalysisForm.get('ageValue').valid) {
        this.state = 'maritalStatus';
      } else {
        this.needAnalysisForm.get('ageValue').markAsDirty();
      }
    } else if (this.state === 'maritalStatus') {
      if (this.needAnalysisForm.get('maritalStatusValue').valid) {
        if (this.needAnalysisForm.get('maritalStatusValue').value === 'Married') {
          this.state = 'kids';
          this.needAnalysisForm.addControl(
            'kidsNumValue',
            new FormControl('', [Validators.required]),
          );
          console.log('inside mrt n kids form', this.needAnalysisForm);
        } else {
          this.state = 'riskType';
        }
      } else {
        this.needAnalysisForm.get('maritalStatusValue').markAsDirty();
      }
      //kids
    } else if (this.state === 'kids') {
      if (this.needAnalysisForm.get('kidsNumValue').valid) {
        this.state = 'riskType';
      } else {
        this.needAnalysisForm.get('kidsNumValue').markAsDirty();
      }
    }
    // else if (this.state === 'occupation') {
    //   if (this.needAnalysisForm.get('occupationValue').valid) {
    //     this.state = 'riskType';
    //   } else {
    //     this.needAnalysisForm.get('occupationValue').markAsDirty();
    //   }

    // }
    else if (this.state === 'riskType') {
      if (this.needAnalysisForm.get('riskTypeValue').valid) {
        this.state = 'annualIncome';
      } else {
        this.needAnalysisForm.get('riskTypeValue').markAsDirty();
      }
      // house type
    }
    // else if (this.state === 'houseType') {
    //   if (this.needAnalysisForm.get('houseTypeValue').valid) {
    //     this.state = 'valuables';
    //   } else {
    //     this.needAnalysisForm.get('houseTypeValue').markAsDirty();
    //   }
    //   // valuables
    // } else if (this.state === 'valuables') {
    //   if (this.needAnalysisForm.get('valuablesValue').valid) {
    //     this.state = 'annualIncome';
    //   } else {
    //     this.needAnalysisForm.get('valuablesValue').markAsDirty();
    //   }
    //   // annual-income
    // }
    else if (this.state === 'annualIncome') {
      if (this.needAnalysisForm.get('annualIncomValue').valid) {
        this.state = 'summary';
      } else {
        this.needAnalysisForm.get('annualIncomValue').markAsDirty();
      }
      // savings
    }
    // else if (this.state === 'savings') {
    //   if (this.needAnalysisForm.get('savingsValue').valid) {
    //     this.state = 'summary';
    //   } else {
    //     this.needAnalysisForm.get('savingsValue').markAsDirty();
    //   }
    //   //need-loan
    // }
    //  else if (this.state === 'needLoan') {
    //   if (this.needAnalysisForm.get('needLoanValue').valid) {
    //     this.state = 'summary';
    //   } else {
    //     this.needAnalysisForm.get('needLoanValue').markAsDirty();
    //   }
    // }

    if (this.state === 'summary' && this.userData.isUserDataValid()) {
      let kidArr = [];
      const needAnalysisData = {
        age: this.needAnalysisForm.get('ageValue').value,
        gender: this.needAnalysisForm.get('genderValue').value,
        maritalStatus: this.needAnalysisForm.get('maritalStatusValue').value,
        // occupation: this.needAnalysisForm.get('occupationValue').value,

        // numKids:2,
        // this.needAnalysisForm.get('genderValue').value,
        // onlinePresence: this.needAnalysisForm.get('socialLifeValue').value,
        riskApetite: this.needAnalysisForm.get('riskTypeValue').value,
        // house: this.needAnalysisForm.get('houseTypeValue').value,
        // posessions: this.userData.getUserInfo().valuables,
        annualIncome: this.needAnalysisForm.get('annualIncomValue').value,
        // disposableIncome: this.needAnalysisForm.get('savingsValue').value,
        // kidAges: [0],
        // numKids: 0
      };
      if (this.needAnalysisForm.get('maritalStatusValue').value === 'Single') {
        kidArr.push(0);
        needAnalysisData['numKids'] = 0;
        needAnalysisData['kidAges'] = 0;
      } else if (this.needAnalysisForm.get('maritalStatusValue').value === 'Married') {
        needAnalysisData['numKids'] = this.needAnalysisForm.get('kidsNumValue').value;
      }
      if (this.needAnalysisForm.get('kidsNumValue')?.value == 1) {
        kidArr.push(this.needAnalysisForm.get('firstKidAge').value);
        needAnalysisData['kidAges'] = this.needAnalysisForm.get('firstKidAge').value;
      } else if (this.needAnalysisForm.get('kidsNumValue')?.value == 2) {
        kidArr.push(this.needAnalysisForm.get('firstKidAge').value);
        kidArr.push(this.needAnalysisForm.get('secondKidAge').value);
        console.log('printing', kidArr);

        needAnalysisData['kidAges'] = kidArr;
      }
      this.userData.needAnalysisData(needAnalysisData, this.customerId).subscribe((res) => {
        this.router.navigate(['needanalysis/summary', this.customerId]);
      });
    } else if (this.state === 'summary' && !this.userData.isUserDataValid()) {
      alert('All fields are need to be filled.');
      // this.needAnalysisForm.controls
      Object.keys(this.needAnalysisForm.controls).filter((control) => {
        if (this.state === 'summary' && !this.needAnalysisForm.get(control).valid) {
          this.state = control.substr(0, control.lastIndexOf('V'));
        }
      });
    }
  }

  // disable next button
  showOrHideNextBtn() {
    if (this.state === 'gender') {
      if (this.needAnalysisForm.get('genderValue').valid && this.userData.getUserInfo().ageGroup) {
        return true;
      } else {
        return false;
      }
    } else if (this.state === 'age') {
      if (this.needAnalysisForm.get('ageValue').valid) {
        return true;
      } else {
        return false;
      }
    } else if (this.state === 'maritalStatus') {
      if (this.needAnalysisForm.get('maritalStatusValue').valid) {
        return true;
        // if (this.needAnalysisForm.get('maritalStatusValue').value === 'Married') {
        //   this.state = 'kids';
        // } else {
        //   this.state = 'occupation';
        // }
      } else {
        return false;
      }
      //kids
    } else if (this.state === 'kids') {
      if (this.needAnalysisForm.get('kidsNumValue')?.valid) {
        return true;
      } else {
        return false;
      }
    }
    // else if (this.state === 'occupation') {
    //   if (this.needAnalysisForm.get('occupationValue').valid) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // }
    else if (this.state === 'riskType') {
      if (this.needAnalysisForm.get('riskTypeValue').valid) {
        return true;
      } else {
        return false;
      }
    }
    // house type

    // else if (this.state === 'houseType') {
    //   if (this.needAnalysisForm.get('houseTypeValue').valid) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // }
    // valuables

    // else if (this.state === 'valuables') {
    //   if (this.needAnalysisForm.get('valuablesValue').valid) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // }
    // annual-income
    else if (this.state === 'annualIncome') {
      if (this.needAnalysisForm.get('annualIncomValue').valid) {
        return true;
      } else {
        return false;
      }
      // savings
    }
    //  else if (this.state === 'savings') {
    //   if (this.needAnalysisForm.get('savingsValue').valid) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // }

    if (this.state === 'summary' && this.userData.isUserDataValid()) {
      return true;
    } else if (this.state === 'summary' && !this.userData.isUserDataValid()) {
      return false;
      // alert('All fields are need to be filled.');
      // this.needAnalysisForm.controls
      // Object.keys(this.needAnalysisForm.controls).filter(control => {
      //   if (this.state === 'summary' && !this.needAnalysisForm.get(control).valid) {
      //     this.state = control.substr(0, control.lastIndexOf('V'));
      //   }
      // });
    }
  }

  onBackTransition() {
    if (this.state === 'needLoan') {
      this.state = 'savings';
    } else if (this.state === 'savings') {
      this.state = 'annualIncome';
    } else if (this.state === 'annualIncome') {
      this.state = 'valuables';
    } else if (this.state === 'valuables') {
      this.state = 'houseType';
    } else if (this.state === 'houseType') {
      this.state = 'riskType';
    } else if (this.state === 'riskType') {
      this.state = 'socialLife';
    } else if (this.state === 'socialLife') {
      this.state = 'occupation';
    } else if (this.state === 'occupation') {
      if (this.needAnalysisForm.get('maritalStatusValue').value === 'Married') {
        this.state = 'kids';
      } else {
        this.state = 'maritalStatus';
      }
    } else if (this.state === 'kids') {
      this.state = 'maritalStatus';
    } else if (this.state === 'maritalStatus') {
      this.state = 'age';
    } else if (this.state === 'age') {
      this.state = 'gender';
    }
  }
}
