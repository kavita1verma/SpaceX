export class UserModel {
    gender: string;
    age: number;
    maritalStatus: string;
    kids: number;
    firstKidAge: number;
    secondKidAge: number;
    thirdKidAge: number;
    occupation: string;
    socialLife: string;
    riskType: string;
    houseType: string;
    valuables: string;
    annualIncome: number;
    savings: number;
    ageGroup:string;
    needLoan: string;

    // public getGender() {
    //     return this.gender;
    // }
    // public getAge() {
    //     return this.age;
    // }
    // public getMaritalStatus() {
    //     return this.maritalStatus;
    // }
    // public getKids() {
    //     return this.kids;
    // }
    // public getOccupation() {
    //     return this.occupation;
    // }
    // public getSocialType() {
    //     return this.socialLife;
    // }
    // public getRiskType() {
    //     return this.riskType;
    // }
    // public getHouseType() {
    //     return this.houseType;
    // }
    // public getValuables() {
    //     return this.valuables;
    // }
    // public getAnnualIncome() {
    //     return this.annualIncome;
    // }
    // public getSavings() {
    //     return this.savings;
    // }
    // public getNeedLoan() {
    //     return this.needLoan;
    // }
    // public getFirstKidAge() {
    //     return this.firstKidAge;
    // }
    // public getSecongKidAge() {
    //     return this.gender;
    // }
    // public getThirdKidAge() {
    //     return this.gender;
    // }

    // public setGender(gender: string) {
    //     this.gender = gender;
    // }
    // public setAge(age: number) {
    //     this.age;
    // }
    // public setMaritalStatus(maritalStatus: string) {
    //     this.maritalStatus = maritalStatus;
    // }
    // public setKids(kids: number) {
    //     this.kids = kids;
    // }
    // public setOccupation(occupation: string) {
    //     this.occupation = occupation;
    // }
    // public setSocialType(socialLife: boolean) {
    //     this.socialLife = socialLife;
    // }
    // public setRiskType(riskType: string) {
    //     this.riskType = riskType;
    // }
    // public setHouseType(houseType: string) {
    //     this.houseType = houseType;
    // }
    // public setValuables(valuables: string[]) {
    //     this.valuables = valuables;
    // }
    // public setAnnualIncome(annualIncome: number) {
    //     this.annualIncome = annualIncome;
    // }
    // public setSavings(savings: number) {
    //     this.savings = savings;
    // }
    // public setNeedLoan(needLoan: boolean) {
    //     this.needLoan = needLoan;
    // }
    // public setFirstKidAge(firstKidAge: number) {
    //     this.firstKidAge = firstKidAge;
    // }
    // public setSecongKidAge(secondKidAge: number) {
    //     this.secondKidAge = secondKidAge;
    // }
    // public setThirdKidAge(thirdKidAge: number) {
    //     this.thirdKidAge = thirdKidAge;
    // }
}