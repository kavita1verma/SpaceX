import { Component, OnInit, HostBinding, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import {
  trigger,
  state,
  style,
  animate,
  transition,
  // ...
} from '@angular/animations';
import { UserDataService } from '../user-data.service';

@Component({
  selector: 'app-risk-type',
  templateUrl: './risk-type.component.html',
  styleUrls: ['./risk-type.component.css'],
  animations: [
    trigger('riskTypeShowHide', [
      state('riskType', style({
        display: 'block',
        opacity: 1,
        marginTop: '0px'
      })),
      state('houseType', style({
        display: 'none',
        opacity: 0,
        marginTop: '-150px'
      })),
      state('*', style({
        marginTop: '150px',
        display: 'none',
        opacity: 0
      })),
      transition('riskType <=> *', [
        animate('1s')
      ])
    ])
  ]
})
export class RiskTypeComponent implements OnInit {
  riskDefiniton = '';

  @Input() state;
  @Input() form: FormGroup;


  constructor(private userDataService: UserDataService) { }

  ngOnInit() {
  }

  onRiskSelected(riskLevel) {
    if (riskLevel === 'Minimal') {
      this.form.get('riskTypeValue').setValue(1);
      this.userDataService.setUserInfo('riskType', 1);
      this.userDataService.setDisplayInfo('riskType', 'Minimal');
      this.riskDefiniton = `
      My priority is capital preservation and
       I am willing to accept minimal risks. In return, 
       I understand that I may receive minimal or low returns.`;
    } else if (riskLevel === 'Moderate') {
      this.form.get('riskTypeValue').setValue(2);
      this.userDataService.setUserInfo('riskType', 2);
      this.userDataService.setDisplayInfo('riskType', 'Moderate');
      this.riskDefiniton = `
      I am willing to accept small/moderate level of risk in 
      exchange for higher potential returns over the medium to long term`;
    } else if (riskLevel === 'Significant') {
      this.form.get('riskTypeValue').setValue(3);
      this.userDataService.setUserInfo('riskType', 3);
      this.userDataService.setDisplayInfo('riskType', 'Significant');
      this.riskDefiniton = `I am willing to accept high or significant 
      risks to maximise my potential returns over the medium to long term. 
      I accept that I may lose a significant part or all my capital.`;
    }
  }
}


