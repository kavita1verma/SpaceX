import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SummaryComponent } from './summary/summary.component';
import { ViewPlanComponent } from './view-plan/view-plan.component';

const routes: Routes = [


  // { path: 'complaints', loadChildren: './complaints/complaints.module#ComplaintsModule'},
  // { path: 'view-complaints', component: ViewComplaintsComponent, canActivate: [AuthGuard] },
  // { path: 'login', component: LoginComponent, },

  // { path: 'login', component: LoginComponent },

  { path: 'home', component: HomeComponent },
  { path: 'home/:customerId', component: HomeComponent },
  { path: 'summary', component: SummaryComponent },
  { path: 'summary/:customerId', component: SummaryComponent },
  { path: 'view-plan', component: ViewPlanComponent },
  { path: 'view-plan/:customerId', component: ViewPlanComponent }
  //  { path: '',
  //   redirectTo: '',
  //   pathMatch: 'full'
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NeedAnalysisRoutingModule { }
