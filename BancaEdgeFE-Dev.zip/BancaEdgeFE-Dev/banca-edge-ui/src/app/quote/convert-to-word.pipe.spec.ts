import { ConvertToWordPipe } from './convert-to-word.pipe';

describe('ConvertToWordPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertToWordPipe();
    expect(pipe).toBeTruthy();
  });
});
