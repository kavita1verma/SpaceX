import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car-insurance',
  templateUrl: './car-insurance.component.html',
  styleUrls: ['./car-insurance.component.css']
})
export class CarInsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
