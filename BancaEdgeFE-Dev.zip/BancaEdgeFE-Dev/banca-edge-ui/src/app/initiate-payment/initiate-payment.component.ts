import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { PolicyErrorModalComponent } from '@app/shared/components/policy-error-modal/policy-error-modal.component';
import { LoaderService } from '@app/_services/loader.service';
import * as moment from 'moment';
import { InitiatePaymentService } from './services/initiate-payment.service';

@Component({
  selector: 'app-initiate-payment',
  templateUrl: './initiate-payment.component.html',
  styleUrls: ['./initiate-payment.component.css'],
})
export class InitiatePaymentComponent implements OnInit, OnDestroy {
  paymentForm: FormGroup;

  accountDetails;

  threeMonthsBack: Date;

  todaysDate: Date;

  applicationNo;

  applicationDetails;

  paymentTypes = [
    { id: 'DBT', value: 'Direct Debit' },
    { id: 'CHQ', value: 'Cheque' },
    { id: 'DD', value: 'Demand Draft' },
  ];

  constructor(
    private paymentService: InitiatePaymentService,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private router: Router,
    public dialog: MatDialog,
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      if (params.appNo) {
        this.applicationNo = params.appNo;
      }
    });
    this.loaderService.showSpinner(true);
    this.todaysDate = new Date();
    const dateBeforeThreeMoths = moment().subtract(3, 'months');
    this.threeMonthsBack = new Date(dateBeforeThreeMoths.toDate());
    this.paymentService.getApplication(this.applicationNo).subscribe(
      (data) => {
        this.applicationDetails = data;
        this.paymentService.getAccountDetails(this.applicationNo).subscribe(
          (accData: []) => {
            this.loaderService.showSpinner(false);
            console.log('the account details', accData);
            this.accountDetails = accData;
            console.log(this.accountDetails);
            if (this.accountDetails.length === 0) {
              const message = {
                isTrue: true,
                message: 'Applicant is not a account holder.Would you like to pay online?',
              };
              const dialogRefOnlinepayment = this.dialog.open(PolicyErrorModalComponent, {
                data: message,
                panelClass: 'dialog-width',
                disableClose: true,
              });
              dialogRefOnlinepayment.afterClosed().subscribe((res) => {
                if (res === 'Online') {
                  this.loaderService.showSpinner(true);
                  this.paymentService.sendCustomerConsent(this.applicationNo).subscribe(
                    (resCC) => {
                      let messagePayLinkSuccess;
                      this.loaderService.showSpinner(false);
                      if (resCC['statusCode'] === '0') {
                        messagePayLinkSuccess = 'Payment Link successfully sent to customer.';
                      } else {
                        messagePayLinkSuccess = 'Payment Link is not sent. Please try again.';
                      }
                      const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
                        data: messagePayLinkSuccess,
                        panelClass: 'dialog-width',
                      });
                      dialogRef.afterClosed().subscribe(() => {
                        this.router.navigate(['/', 'policyvault']);
                      });
                    },
                    () => {
                      this.loaderService.showSpinner(false);
                      const messagePayLink =
                        'Unable to send paymentLink. Please try again after sometime.';
                      const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
                        data: messagePayLink,
                        panelClass: 'dialog-width',
                      });
                      dialogRef.afterClosed().subscribe(() => {
                        this.router.navigate(['/', 'policyvault']);
                      });
                    },
                  );
                }
              });
            }
            this.generateFormFields();
          },
          () => {
            this.loaderService.showSpinner(false);
            const message = 'Error fetching account details';
            const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
              data: message,
              panelClass: 'dialog-width',
              disableClose: true,
            });
            dialogRef.afterClosed().subscribe(() => {
              this.router.navigate(['/', 'policyvault']);
            });
            this.accountDetails = [];
            this.generateFormFields();
          },
        );
      },
      () => {
        this.loaderService.showSpinner(false);
      },
    );
  }

  initiatePayment() {
    let instrumentDate;
    const paymentType = this.paymentForm.get('paymentType').value;
    if (paymentType !== 'DBT') {
      const checkDate = new Date(this.paymentForm.get('chkOrDDDate').value);
      instrumentDate =
        checkDate.getFullYear() +
        '-' +
        ('0' + (checkDate.getMonth() + 1)).slice(-2) +
        '-' +
        ('0' + checkDate.getDate()).slice(-2);
    }
    const paymentBody = {
      paymentType,
      cifNo: paymentType === 'DBT' ? this.accountDetails[0].cifNo : undefined,
      accountNo: paymentType === 'DBT' ? this.paymentForm.get('accountNumber').value : undefined,
      instrumentDate,
      instrumentNo: paymentType !== 'DBT' ? this.paymentForm.get('chequeOrDDNo').value : undefined,
      ifscCode: paymentType !== 'DBT' ? this.paymentForm.get('ifscCode').value : undefined,
      micrCode: paymentType !== 'DBT' ? this.paymentForm.get('micrCode').value : undefined,
      insurerId: this.applicationDetails.insurerCode,
      premiumPayable: this.applicationDetails.premiumAmount,
      appNo: this.applicationDetails.applicationNo,
    };
    this.loaderService.showSpinner(true);
    this.paymentService.initiatePayment(paymentBody).subscribe(
      (data) => {
        console.log('Printing Initiate PaymentData', data);
        if (data['responseCode'] === 0) {
          this.loaderService.showSpinner(false);
          const message = 'Your payment request has been sent for approval.';
          const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
            data: message,
            panelClass: 'dialog-width',
          });
          dialogRef.afterClosed().subscribe(() => {
            this.router.navigate(['/', 'payment-approval']);
          });
        } else {
          this.loaderService.showSpinner(false);
          const message = data['responseMessage'];
          this.dialog.open(PolicyErrorModalComponent, {
            data: message,
            panelClass: 'dialog-width',
          });
        }
      },
      () => {
        this.loaderService.showSpinner(false);
      },
    );
  }

  generateFormFields() {
    console.log('coming here');
    const today = new Date();
    if (this.accountDetails && this.accountDetails.length > 0) {
      console.log('step 1');
      this.paymentForm = new FormGroup({});
      this.paymentForm.addControl('paymentType', new FormControl('DBT', Validators.required));
      this.paymentForm.addControl(
        'accountNumber',
        new FormControl(this.accountDetails[0].accountNo),
      );
      console.log('step 2');
    } else {
      console.log('step 3');
      this.paymentForm = new FormGroup({});
      this.paymentForm.addControl('paymentType', new FormControl('CHQ', [Validators.required]));
      this.paymentForm.addControl(
        'chequeOrDDNo',
        new FormControl('', [Validators.required, Validators.pattern(/[0-9]{6}/)]),
      );
      this.paymentForm.addControl('chkOrDDDate', new FormControl('', [Validators.required]));
      this.paymentForm.addControl(
        'ifscCode',
        new FormControl('', [Validators.required, Validators.pattern(/^[A-Z]{4}0[0-9]{6}$/)]),
      );
      this.paymentForm.addControl(
        'micrCode',
        new FormControl('', [Validators.required, Validators.pattern(/[0-9]{9}/)]),
      );
      console.log('step 4');
    }
    console.log('checked', this.applicationDetails);
    this.paymentForm.addControl('confirmationConsent', new FormControl(null, Validators.required));
    this.paymentForm.addControl(
      'premiumPayable',
      new FormControl(this.applicationDetails.premiumAmount),
    );
    this.paymentForm.addControl(
      'insurerName',
      new FormControl(this.applicationDetails.insurerName),
    );
    this.paymentForm.addControl(
      'customerName',
      new FormControl(this.applicationDetails.customerName),
    );
    this.paymentForm.addControl(
      'dateOfPayment',
      new FormControl(today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear()),
    );
    console.log('last step is aslo working fine..', this.paymentForm);
  }

  onPaymentMethodChange(event) {
    if (event.value === 'DBT') {
      this.paymentForm.addControl(
        'accountNumber',
        new FormControl(this.accountDetails[0].accountNo, Validators.required),
      );
      this.paymentForm.removeControl('chequeOrDDNo');
      this.paymentForm.removeControl('chkOrDDDate');
      this.paymentForm.removeControl('ifscCode');
      this.paymentForm.removeControl('micrCode');
    } else {
      this.paymentForm.removeControl('accountNumber');
      this.paymentForm.addControl(
        'chequeOrDDNo',
        new FormControl('', [Validators.required, Validators.pattern(/[0-9]{6}/)]),
      );
      this.paymentForm.addControl('chkOrDDDate', new FormControl('', [Validators.required]));
      this.paymentForm.addControl(
        'ifscCode',
        new FormControl('', [Validators.required, Validators.pattern(/^[A-Z]{4}0[0-9]{6}$/)]),
      );
      this.paymentForm.addControl(
        'micrCode',
        new FormControl('', [Validators.required, Validators.pattern(/[0-9]{9}/)]),
      );
    }
  }

  ngOnDestroy() {
    console.log('on destroy has been called');
  }
}
