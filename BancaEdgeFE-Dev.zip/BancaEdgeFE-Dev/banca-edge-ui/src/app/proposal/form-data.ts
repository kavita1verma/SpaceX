export interface FormData {
  controlName: string;
  controlType: string;
  initiallyDisabled: boolean;
  valueType: string;
  currentValue?: string;
  placeholder?: string;
  options?: Array<{
    id: string;
    value: string;
  }>;
  validators?: {
    required?: boolean;
    minLength?: number;
    maxLength?: number;
    min?: number;
    max?: number;
    pattern?: string;
    email?: boolean;
  };
}

export const sampleProposalMetaData = {};

export const sampleApplicationData = {};
