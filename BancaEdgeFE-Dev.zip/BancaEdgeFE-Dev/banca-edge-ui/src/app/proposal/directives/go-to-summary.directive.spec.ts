import { GoToSummaryDirective } from './go-to-summary.directive';

describe('GoToSummaryDirective', () => {
  it('should create an instance', () => {
    // const directive = new GoToSummaryDirective();
    // expect(directive).toBeTruthy();
  });
});
