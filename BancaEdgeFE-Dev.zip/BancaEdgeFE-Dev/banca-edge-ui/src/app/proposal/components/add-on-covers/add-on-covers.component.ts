import { Component, Input, OnInit, Output, EventEmitter, OnChanges } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-on-covers',
  templateUrl: './add-on-covers.component.html',
  styleUrls: ['./add-on-covers.component.css'],
})
export class AddOnCoversComponent implements OnInit, OnChanges {
  @Input() covers;

  @Input() addOnForm: FormGroup;

  @Input() illustrationLink: string;

  @Input() insuredData;

  @Input() insuredAge;

  @Input() errorFromCovers;

  @Output() recalculatePremiumClicked = new EventEmitter();

  ngOnInit() {
    this.covers.forEach((cover, index) => {
      if (cover.saRequired) {
        this.addOnForm.addControl(cover.coverId + 'sumInsured', new FormControl(cover.sa));
        this.addOnForm.get(cover.coverId + 'sumInsured').valueChanges.subscribe((data) => {
          if (this.covers[index].selected && data > 0) {
            this.addOnForm.addControl('recalculate', new FormControl('', Validators.required));
            this.addOnForm.controls['recalculate'].updateValueAndValidity();
          } else if (!this.covers[index].selected && data === 0) {
            this.addOnForm.addControl('recalculate', new FormControl('', Validators.required));
            this.addOnForm.controls['recalculate'].updateValueAndValidity();
          }
        });
      }
    });
    this.recalculatePremiumClicked.emit(true);
    this.addOnForm.addControl('viewIllustration', new FormControl('', Validators.required));
  }

  ngOnChanges(changes) {
    console.log(changes);
    // if (changes.covers) {
    //     this.covers.forEach((cover, index) => {
    //         if (!this.addOnForm.get(cover.coverId + 'sumInsured')) {
    //             this.addOnForm.addControl(cover.coverId + 'sumInsured', new FormControl(cover.sa));
    //             this.addOnForm.get(cover.coverId + 'sumInsured').valueChanges.subscribe(data => {
    //                 if (cover.selected && data > 0) {
    //                     this.addOnForm.addControl('recalculate', new FormControl('', Validators.required));
    //                     this.addOnForm.controls['recalculate'].updateValueAndValidity();
    //                 } else if (!this.covers[index].selected && data === 0) {
    //                     this.addOnForm.addControl('recalculate', new FormControl('', Validators.required));
    //                     this.addOnForm.controls['recalculate'].updateValueAndValidity();
    //                 }
    //             });
    //         }
    //     });
    // }
  }

  onAddCover(index) {
    this.covers[index].selected = true;
    const cover = this.covers[index];
    this.addOnForm.addControl('recalculate', new FormControl('', Validators.required));
    if (cover.saRequired) {
      const validators = [];
      if (cover.attribute && cover.attribute.maxSa) {
        validators.push(Validators.max(+cover.attribute.maxSa));
      } else {
        validators.push(Validators.max(this.insuredData?.applicationData?.sumInsured));
      }
      if (cover.attribute && cover.attribute.minSa) {
        validators.push(Validators.min(+cover.attribute.minSa));
      }
      validators.push(Validators.required);
      validators.push(Validators.pattern(/^[1-9][0-9]*0{3}$/));
      this.addOnForm.get(cover.coverId + 'sumInsured').setValidators(validators);

      this.addOnForm.get(cover.coverId + 'sumInsured').setValidators(validators);
      this.addOnForm.controls[cover.coverId + 'sumInsured'].updateValueAndValidity();
    } else if (cover.premium[this.insuredData.mode].premium > 0) {
      const netPremium = cover.premium[this.insuredData.mode].netPremium;
      const premium = cover.premium[this.insuredData.mode].premium;
      const gst = premium - netPremium;
      this.insuredData.basePremium += netPremium;
      this.insuredData.premiumAmount += premium;
      this.insuredData.gst += gst;
    }
  }

  onRemoveCover(index) {
    this.covers[index].selected = false;
    const cover = this.covers[index];
    cover.sa = 0;
    this.addOnForm.addControl('recalculate', new FormControl('', Validators.required));
    if (cover.saRequired) {
      this.addOnForm.get(cover.coverId + 'sumInsured').clearValidators();
      this.addOnForm.get(cover.coverId + 'sumInsured').setValue(0);
      this.addOnForm.controls[cover.coverId + 'sumInsured'].updateValueAndValidity();
    } else if (cover.premium[this.insuredData.mode].premium > 0) {
      const netPremium = cover.premium[this.insuredData.mode].netPremium;
      const premium = cover.premium[this.insuredData.mode].premium;
      const gst = premium - netPremium;
      this.insuredData.basePremium -= netPremium;
      this.insuredData.premiumAmount -= premium;
      this.insuredData.gst -= gst;
    }
  }

  onSumInsuredChanged(event, index) {
    this.covers[index].sa = +event.target.value;
  }

  onRecalculateClicked() {
    console.log('working fine till here recalcute');
    this.recalculatePremiumClicked.emit(true);
    this.addOnForm.removeControl('recalculate');
    this.addOnForm.get('viewIllustration').setValidators(Validators.required);
    this.addOnForm.get('viewIllustration').updateValueAndValidity();
  }

  onViewIllustrationClicked() {
    if (!this.errorFromCovers) {
      this.addOnForm.get('viewIllustration').setValidators([]);
      this.addOnForm.get('viewIllustration').updateValueAndValidity();
    }
  }
}
