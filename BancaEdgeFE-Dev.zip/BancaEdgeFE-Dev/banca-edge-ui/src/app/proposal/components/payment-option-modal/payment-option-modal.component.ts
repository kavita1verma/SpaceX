import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-payment-option-modal',
    templateUrl: './payment-option-modal.component.html',
    styleUrls: ['./payment-option-modal.component.css']
})
export class PaymentOptionModalComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data,
        private dialogRef: MatDialogRef<PaymentOptionModalComponent>
    ) { }

    ngOnInit() {
        console.log('got the data', this.data);
    }

    onClick(type) {
        this.dialogRef.close(type);
    }
}
