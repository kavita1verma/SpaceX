import { DisplayMedicalSectionPipe } from './display-medical-section.pipe';

describe('DisplayMedicalSectionPipe', () => {
  it('create an instance', () => {
    const pipe = new DisplayMedicalSectionPipe();
    expect(pipe).toBeTruthy();
  });
});
