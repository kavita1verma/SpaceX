import { DisplayFormFieldPipe } from './display-form-field.pipe';

describe('DisplayFormFieldPipe', () => {
  it('create an instance', () => {
    const pipe = new DisplayFormFieldPipe();
    expect(pipe).toBeTruthy();
  });
});
