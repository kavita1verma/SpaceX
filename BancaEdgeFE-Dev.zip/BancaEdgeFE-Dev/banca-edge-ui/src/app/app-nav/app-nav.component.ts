import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { AccountService, TokenService } from '@app/_services';
// import { BlockerService } from '@app/_services';
import { User } from '@app/_models';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-nav',
  templateUrl: './app-nav.component.html',
  styleUrls: ['./app-nav.component.css'],
})
export class AppNavComponent implements OnInit {
  user: User;

  isOpened = false;

  notificationArr;

  notificationCount = 0;

  orgLogo;

  rolesArr;

  firstName;

  lastName;

  isBankCustomer;

  isGuestUser = false;

  isBranchUser;

  // V--View, E--Edit , C--Create , S--Services
  isViewActivity;

  isCreateQuote;

  isViewSr;

  isCreateComplaint;

  isViewCustomer;

  isDashboard;

  isRenewPolicy;

  isViewPolicyVault;

  isUwActivity;

  isGroupCredit;

  // isGroupCredit;
  isQuoteV;

  isPolicyV;

  isPolicyS;

  isCustomerV;

  orgName;

  isViewLead;

  orgCode;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map((result) => result.matches),
    shareReplay(),
  );

  constructor(
    private breakpointObserver: BreakpointObserver,
    private accountService: AccountService,
    private tokenService: TokenService, // private blockerService: BlockerService
  ) {
    this.accountService.user.subscribe((x) => (this.user = x));

    this.getNotificationList();
    // this.customerArr.map(customer => {
    //   customer['expanded'] = false;
    //   customer['cDate'] = new Date(customer.createdDate);
    // });
  }

  ngOnInit() {
    if (this.user) {
      this.orgCode = this.user.organizationCode;
      this.firstName = this.user['firstName'];
      this.lastName = this.user['lastName'];
      this.rolesArr = this.user.roles;
      if (this.user['bankCustomer'] === 'false') {
        this.isBankCustomer = false;
        // console.log('is tur ot falee', this.isBankCustomer);
      } else if (this.user['bankCustomer'] === 'true') {
        this.isBankCustomer = true;
        // console.log('is tur ot falee', this.isBankCustomer);
      }
      if (this.user['userName'] === 'bomguest@lastdecimal.com') {
        this.isGuestUser = true;
      }
      this.accountService.validateToken(this.tokenService.token).subscribe(
        (data) => {},
        (error) => {
          this.accountService.logout().subscribe(
            (logoutData) => {
              this.tokenService.isTokenSubject.next(null);
            },
            (error) => {},
          );
        },
      );
    }

    if (!this.user) {
      this.orgName = this.accountService.orgCode;
      if (this.orgName === 'BOM') {
        this.orgLogo = 'https://s3.amazonaws.com/lastdecimal.brokeredge.data/ilogo/bom.svg';
      } else if (this.orgName === null) {
        this.orgLogo = 'https://s3.amazonaws.com/lastdecimal.brokeredge.data/ilogo/bom.svg';
      }
    } else {
      this.orgLogo = this.user['orgLogo'];
    }

    this.isBranchUser = this.accountService.isBranchUser;
    // console.log('branch user', this.accountService.isBranchUser);
    // console.log('bank', this.user['bankCustomer'], this.user);

    if (this.rolesArr && this.rolesArr.length > 0) {
      // this.isQuoteV = true;
      this.checkForRoles();
    }
  }

  checkForRoles() {
    this.viewActivity();
    this.createQuote();
    this.createServiceRequest();
    this.createComplaint();
    this.viewCustomer();
    this.viewDashboard();
    this.renewPolicy();
    this.viewPolicyVault();
    this.viewGroupCredit();
    this.viewUvwActivity();
    this.viewLeadsActivity();
  }

  viewActivity() {
    if (
      this.rolesArr.indexOf('CUSTOMER.ACTIVITIES.LIST') > -1 ||
      this.rolesArr.indexOf('BRANCH.ACTIVITIES.LIST') > -1 ||
      this.rolesArr.indexOf('INSURER.ACTIVITIES.LIST') > -1
    ) {
      this.isViewActivity = true;
    } else {
      this.isViewActivity = false;
    }
  }

  viewUvwActivity() {
    if (
      this.rolesArr.indexOf('INSURER.UW.VIEW') > -1 ||
      this.rolesArr.indexOf('INSURER.UW.UPDATE') > -1
    ) {
      this.isUwActivity = true;
    } else {
      this.isUwActivity = false;
    }
  }

  viewLeadsActivity() {
    if (
      this.rolesArr.indexOf('BRANCH.QUOTE.CREATE') > -1 ||
      this.rolesArr.indexOf('BRANCH.QUOTE.VIEW') > -1 ||
      this.rolesArr.indexOf('INSURER.QUOTE.CREATE') > -1 ||
      this.rolesArr.indexOf('INSURER.QUOTE.VIEW') > -1
    ) {
      this.isViewLead = true;
    } else {
      this.isViewLead = false;
    }
  }

  createQuote() {
    if (
      this.rolesArr.indexOf('BRANCH.QUOTE.CREATE') > -1 ||
      this.rolesArr.indexOf('CUSTOMER.QUOTE.CREATE') > -1
    ) {
      this.isCreateQuote = true;
    } else {
      this.isCreateQuote = false;
    }
  }

  createServiceRequest() {
    if (
      this.rolesArr.indexOf('BRANCH.SR.VIEW') > -1 ||
      this.rolesArr.indexOf('CUSTOMER.SR.VIEW') > -1 ||
      this.rolesArr.indexOf('INSURER.SR.VIEW') > -1
    ) {
      this.isViewSr = true;
    } else {
      this.isViewSr = false;
    }
  }

  createComplaint() {
    if (
      this.rolesArr.indexOf('BRANCH.COMPLAINT.CREATE') > -1 ||
      this.rolesArr.indexOf('CUSTOMER.COMPLAINT.CREATE') > -1
    ) {
      this.isCreateComplaint = true;
    } else {
      this.isCreateComplaint = false;
    }
  }

  viewCustomer() {
    if (
      this.rolesArr.indexOf('BRANCH.CUSTOMER.VIEW') > -1 ||
      this.rolesArr.indexOf('INSURER.CUSTOMER.VIEW')
    ) {
      this.isViewCustomer = true;
    } else {
      this.isViewCustomer = false;
    }
  }

  viewDashboard() {
    if (this.rolesArr.indexOf('BRANCH.REPORT.VIEW') > -1) {
      this.isDashboard = true;
    } else {
      this.isDashboard = false;
    }
  }

  renewPolicy() {
    if (this.rolesArr.indexOf('BRANCH.POLICY.CREATE') > -1) {
      this.isRenewPolicy = true;
    } else {
      this.isRenewPolicy = false;
    }
  }

  viewPolicyVault() {
    if (
      this.rolesArr.indexOf('BRANCH.POLICY.VIEW') > -1 ||
      this.rolesArr.indexOf('CUSTOMER.POLICY.VIEW') > -1 ||
      this.rolesArr.indexOf('INSURER.POLICY.VIEW') > -1
    ) {
      this.isViewPolicyVault = true;
    } else {
      this.isViewPolicyVault = false;
    }
  }

  viewGroupCredit() {
    if (
      this.rolesArr.indexOf('BRANCH.POLICY.VIEW') > -1 ||
      this.rolesArr.indexOf('CUSTOMER.POLICY.VIEW') > -1 ||
      this.rolesArr.indexOf('INSURER.POLICY.VIEW') > -1
    ) {
      this.isGroupCredit = true;
    } else {
      this.isGroupCredit = false;
    }
  }

  logout() {
    // this.blockerService.logout();
    this.accountService.logout().subscribe(
      (logoutResponse) => {
        // console.log(logoutResponse, ' <= logout repsonse');
        // this.accountService.cleanup();
      },
      (error) => {
        console.log('Error logging out', error);
        this.accountService.cleanup();
      },
      () => {
        console.log('Logged out got a complete notification');
      },
    );
  }

  getNotificationList() {
    // this.accountService.getNotificationList().subscribe(notification => {
    //   console.log('api returned', notification);
    //   this.notificationArr = notification;
    //   console.log(this.notificationArr);
    //   this.notificationCount = this.notificationArr.length;
    //   });
  }

  delNotification(position) {
    this.accountService.markNotificationRead(this.notificationArr[position]).subscribe((res) => {
      this.getNotificationList();
    });
  }

  get isUser() {
    if (this.user) {
      return this.accountService.isUser;
    } else {
      return false;
    }
  }
}
