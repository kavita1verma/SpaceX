import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AlertModule } from '@app/_components/alert.module';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input'; import { MatButtonModule } from '@angular/material/button';
import { AccountService, AlertService } from '@app/_services';
import { state } from '@angular/animations';
import { LoaderService } from '@app/_services/loader.service';

@Component({
    templateUrl: 'login.component.html',
    styleUrls: ['login.component.css']
})
export class LoginComponent implements OnInit {
    form: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    isPasswordVisible = false;
    @ViewChild('password') MyProp: ElementRef;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private accountService: AccountService,
        private alertService: AlertService,
        private loaderService: LoaderService
    ) { }

    ngOnInit() {
        this.form = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });
        this.returnUrl = localStorage.getItem('currentUrl');
    }

    get f() { return this.form.controls; }

    onSubmit() {
        this.submitted = true;


        this.alertService.clear();

        if (this.form.invalid) {
            const sentence = 'Failed to login';
            return sentence;
        }

        this.loaderService.showSpinner(true);
        this.accountService.login(this.f.username.value, this.f.password.value)
            .pipe(first())
            .subscribe(
                data => {
                    this.loaderService.showSpinner(false);
                    if (this.accountService.isInsurer == true) {
                        console.log('insnde login inusrer true');
                        this.router.navigate(['policyvault']);
                    } else {
                        this.router.navigateByUrl(this.returnUrl);

                    }
                },
                error => {
                    this.alertService.error(error);
                    this.loaderService.showSpinner(false);
                });
    }

    forgotPassword() {
        this.router.navigate(['account/forgotpassword']);
    }
    register() {
        this.router.navigate(['account/registerCustomer']);
    }
    togglePassword(val) {
        if (val) {
            this.MyProp.nativeElement.type = 'text';
            this.isPasswordVisible = true;
        } else {
            this.MyProp.nativeElement.type = 'password';
            this.isPasswordVisible = false;


        }
    }

    omitSpecialChar(event) {
        let k;
        k = event.charCode;
        console.log(k);
        //         k = event.keyCode;  (Both can be used)
        return ((k > 63 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || k == 46 || (k >= 48 && k <= 57));
    }
}
