import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { RegisterCustomerComponent } from './register-customer/register-customer.component';


const routes: Routes = [


    // { path: 'registerCustomer', component: RegisterCustomerComponent }



];

@NgModule({
    imports: [RouterModule],
    exports: [RouterModule]
})

export class RegisterRoutingModule { }
