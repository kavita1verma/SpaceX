import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RecommendService } from '@app/loan-account/service/recommend-service';
import { PolicyErrorModalComponent } from '@app/shared/components/policy-error-modal/policy-error-modal.component';
import { LoaderService } from '@app/_services/loader.service';

@Component({
  selector: 'app-loan-details',
  templateUrl: './loan-details.component.html',
  styleUrls: ['./loan-details.component.css']
})
export class LoanDetailsComponent implements OnInit, OnChanges {
  quoteId;
  recommendationData;
  currentLoanType;
  @Input() applicationDetails;
  @Input() inputType;
  @Input() loanTypeMaster;

  constructor(
    private loaderService: LoaderService,
    private recommendService: RecommendService,
    private router: Router,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes) {
    if (changes.loanTypeMaster && this.loanTypeMaster) {
      const results = this.loanTypeMaster.find(element => element.id === this.applicationDetails.loanType.toString());
      this.currentLoanType = results;
    }
  }

  onRecommendClick() {
    this.loaderService.showSpinner(true);
    const reqbody = {
      inputType: this.inputType,
      loanAccountNo: this.applicationDetails.loanAccountNo
    };
    this.recommendService.recommendInsuranceDetails(reqbody).subscribe(data => {
      this.loaderService.showSpinner(false);
      if (data['responseCode'] === 0 && data['numQuotesExpected'] > 0) {
        this.quoteId = data['quoteId'];
        this.router.navigate(['group-credit', 'loan-quote', this.quoteId]);
      } else {
        const message = data['responseMessage'];
        this.openErrorModal(message);
      }
    }, error => {
      this.loaderService.showSpinner(false);
      const message = 'Unable to fetch the data';
      this.openErrorModal(message);
    });
  }

  openErrorModal(message) {
    const dialogRef = this.dialog.open(PolicyErrorModalComponent, {
      data: message,
      panelClass: 'dialog-width'
    });
  }


}
