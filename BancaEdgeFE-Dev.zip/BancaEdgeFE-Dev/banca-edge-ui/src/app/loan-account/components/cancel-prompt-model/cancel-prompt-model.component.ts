import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-prompt-model',
  templateUrl: './cancel-prompt-model.component.html',
  styleUrls: ['./cancel-prompt-model.component.css']
})
export class CancelPromptModelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
