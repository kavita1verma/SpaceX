import { Injectable } from '@angular/core';
import { Observable, of, partition } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@environments/environment';
import { AccountService } from '@app/_services/account.service';
import { TokenService } from '../../_services';

@Injectable({
  providedIn: 'root'
})
export class LoanService {

  constructor(private http: HttpClient) { }

  submitLoanDetails(loanDetails) {
    const headers = new HttpHeaders();
    return this.http.post(`${environment.apiUrl}/api/v1/attachment/getLoanDetails`, loanDetails);
  }

  addLoanDetails(addLoan) {
    return this.http.post(`${environment.apiUrl}/api/v1/attachment/addLoanDetails`, addLoan);
  }

  getFromMaster(productId, masterName) {
    return this.http.get(`api/v1/master/getMasterCodes/${masterName}/${productId}`);
  }

  getInputType(inputType, loanAccountNumber) {
    return this.http.get(`${environment.apiUrl}/api/v1/attachment/addLoanDetails/${inputType}/${loanAccountNumber}`);
  }

  getAllowedBranches() {
    return this.http.get(`${environment.apiUrl}/api/v1/master/getAllowedBranches`);
  }
}
